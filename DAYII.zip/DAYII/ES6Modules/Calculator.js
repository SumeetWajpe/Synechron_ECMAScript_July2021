// import Addition, { Multiply } from "./MathModule.js";

import * as MathModule from "./MathModule.js";

console.log(`The addition is : ${MathModule.default(20, 30)}`);
console.log(`The product is : ${MathModule.Multiply(20, 30)}`);
