export default function Add(x, y) {
  // 1 default export per module/file
  return x + y;
}
export function Multiply(x, y) {
  return x * y;
}

function Divide(x, y) {
  return x / y;
}
