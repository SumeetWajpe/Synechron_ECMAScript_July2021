function FetchPostsData() {
  return fetch("https://jsonplaceholder.typicode.com/posts");
}

// function FetchPostsData() {
//   fetch("https://jsonplaceholder.typicode.com/posts", { method: "POST" })
//     .then((response) => response.json())
//     .then((posts) => console.log(posts));
// }
