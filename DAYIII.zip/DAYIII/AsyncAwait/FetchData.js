function FetchPostsData() {
  return fetch("https://jsonplaceholder.typicode.com/postss").then(
    (response) => {
      // console.log(response);
      if (!response.ok) {
        throw Error("Something went wrong !");
      }
      return response.json();
    }
  );
}
