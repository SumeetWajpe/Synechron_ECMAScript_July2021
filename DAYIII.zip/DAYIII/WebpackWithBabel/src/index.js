class Point {
  x = 100;
  y = 100;
}

let Add = (x, y) => x + y;
