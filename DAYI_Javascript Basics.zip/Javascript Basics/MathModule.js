var MathModule = (function () {
  function Addition(x, y) {
    console.log("Adding..");
    return x + y;
  }
  function Multiply(x, y) {
    console.log("Multiplying..");
    return x * y;
  }
  return {
    Add: Addition,
  };
})();
